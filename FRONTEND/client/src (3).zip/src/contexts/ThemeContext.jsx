// src/contexts/ThemeContext.jsx
import React, { createContext, useMemo, useState, useContext, useEffect } from 'react';
import { createTheme, ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { alpha } from '@mui/material/styles';

// Create a context to hold the theme mode and toggle function
const ColorModeContext = createContext({ toggleColorMode: () => {} });

export function useColorMode() {
  return useContext(ColorModeContext);
}

export function ThemeContextProvider({ children }) {
  // Use state to track the current mode, with 'light' as the default.
  // We use a function to initialize the state from localStorage.
  const [mode, setMode] = useState(() => {
    try {
      // Check if a theme is saved in local storage
      const savedMode = localStorage.getItem('themeMode');
      // If a mode is found, use it; otherwise, default to 'light'
      return savedMode || 'light';
    } catch (error) {
      // Handle cases where localStorage is not available (e.g., private Browse)
      console.error("Could not access localStorage. Defaulting to 'light' mode.", error);
      return 'light';
    }
  });

  // Use a useEffect hook to update localStorage whenever the 'mode' state changes.
  useEffect(() => {
    try {
      localStorage.setItem('themeMode', mode);
    } catch (error) {
      console.error("Could not save theme to localStorage.", error);
    }
  }, [mode]);

  // Memoize the toggle function to prevent unnecessary re-renders
  const colorMode = useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
      },
    }),
    []
  );

  // Memoize the theme object. It will only be re-created if the 'mode' changes.
  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode,
          // --- Shared colors for both modes ---
          warning: {
            main: '#ff9800', // This is the main orange color for the lightbulb icon
          },
          // --- Custom Palettes based on mode ---
          ...(mode === 'light'
            ? {
                // LIGHT MODE: Colors extracted and generalized from StudyTips.jsx
                primary: {
                  main: '#ff9800', // Orange
                  light: '#ffc947',
                  dark: '#c66900',
                  contrastText: '#ffffff',
                },
                secondary: {
                  main: '#f50057', // Pink accent
                },
                background: {
                  default: '#f4f6f8', // Very light grey background
                  // The 'paper' color is the background for your glassmorphism cards/boxes
                  paper: 'rgba(255, 255, 255, 0.2)', // Translucent white for glass effect
                },
                text: {
                  primary: 'rgba(0, 0, 0, 0.87)',
                  secondary: 'rgba(0, 0, 0, 0.6)',
                },
                // --- CUSTOM GLASSMORHISM COLORS FOR LIGHT MODE ---
                glass: {
                  // Outer box of a glassmorphic card
                  outer: 'rgba(255, 255, 255, 0.6)',
                  outerBorder: 'rgb(255, 255, 255)',
                  // Inner box/card within the outer box
                  inner: 'rgba(255, 255, 255, 0.9)',
                  innerBorder: 'rgba(255, 255, 255, 0.8)',
                  // Specific text colors from the component
                  heading: '#4a2e00',
                  body: '#5c3b0f',
                },
                // --- NEW: Timer color for light mode ---
                SeanceActivetimer: {
                    main: '#000000', // A strong, dark orange
                },
              }
            : {
                // DARK MODE: Colors extracted and generalized from StudyTips.jsx
                primary: {
                  main: '#673ab7', // Deep Purple
                  light: '#9a67ea',
                  dark: '#320b86',
                  contrastText: '#ffffff',
                },
                secondary: {
                  main: '#2196f3', // Blue accent
                },
                background: {
                  default: '#1a1a2e', // Dark blue background
                  // The 'paper' color for the dark glassmorphism effect
                  paper: 'rgba(255, 255, 255, 0.05)', // A very subtle translucent white/grey
                },
                // --- CORRECTED TEXT COLORS FOR DARK MODE ---
                text: {
                  primary: '#e0e0e0', // A soft white/light grey for main text
                  secondary: 'rgba(224, 224, 224, 0.7)', // A translucent version for secondary text
                },
                // --- CUSTOM GLASSMORHISM COLORS FOR DARK MODE ---
                glass: {
                  // Outer box of a glassmorphic card
                  outer: 'rgba(0, 0, 0, 0.4)',
                  outerBorder: 'rgba(255,255,255,0.2)',
                  // Inner box/card within the outer box
                  inner: 'rgba(0, 0, 0, 0.6)',
                  innerBorder: 'rgba(255,255,255,0.6)',
                  // Specific text colors from the component
                  heading: '#e0e0e0', // Using primary text color for headings in dark mode
                  body: 'rgba(224, 224, 224, 0.7)', // Using secondary text color for body in dark mode
                },
                // --- NEW: Timer color for dark mode ---
                SeanceActivetimer: {
                    main: '#ffffff', // A bright yellow/orange to stand out
                },
              }),
        },
        // --- Shared styles for both modes ---
        typography: {
          fontFamily: 'Poppins, sans-serif',
          h3: {
            fontWeight: 700,
          },
          h5: {
            fontWeight: 400,
          },
          h6: {
            fontWeight: 700,
            letterSpacing: '0.5px',
          },
          body2: {
            fontStyle: 'italic',
            lineHeight: 1.4,
          }
        },
        // You can add more global styles here if needed
      }),
    [mode]
  );

  return (
    <ColorModeContext.Provider value={colorMode}>
      <MuiThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </MuiThemeProvider>
    </ColorModeContext.Provider>
  );
}