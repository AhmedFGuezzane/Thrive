import React, { useState, useEffect, useContext } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Grid,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Checkbox,
  FormControlLabel,
  useTheme,
} from '@mui/material';
import { alpha } from '@mui/material/styles';

// Import icons
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import LoopIcon from '@mui/icons-material/Loop';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import TimerIcon from '@mui/icons-material/Timer';

// Import TimerContext
import { TimerContext } from '../../contexts/TimerContext';

export default function TaskDetailsDialog({
  open,
  onClose,
  taskDetails,
  onUpdateTask,
  getImportanceDisplay,
  getStatusDisplay,
  showSnackbar,
}) {
  const theme = useTheme();
  const { activeSeanceId } = useContext(TimerContext);

  const [editedTaskData, setEditedTaskData] = useState({});
  const [isLinkedToActiveSeance, setIsLinkedToActiveSeance] = useState(false);

  useEffect(() => {
    if (taskDetails) {
      setEditedTaskData({
        ...taskDetails,
        date_fin: taskDetails.date_fin ? new Date(taskDetails.date_fin).toISOString().split('T')[0] : '',
        statut: String(taskDetails.statut).toLowerCase() || 'en attente',
        priorite: taskDetails.priorite || '',
        duree_estimee: taskDetails.duree_estimee || '',
        duree_reelle: taskDetails.duree_reelle || '',
      });

      setIsLinkedToActiveSeance(taskDetails.seance_etude_id === activeSeanceId && !!activeSeanceId);
    }
  }, [taskDetails, activeSeanceId]);

  const handleFieldChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    setEditedTaskData(prev => ({
      ...prev,
      [name]: newValue
    }));
  };

  const handleCheckboxChange = (e) => {
    setIsLinkedToActiveSeance(e.target.checked);
  };

  const handleSave = async () => {
    if (!editedTaskData.titre) {
      showSnackbar("Le titre de la tâche est requis.", "error");
      return;
    }

    try {
      showSnackbar("Mise à jour de la tâche...", "info", true);

      const payload = {
        ...editedTaskData,
        date_fin: editedTaskData.date_fin ? new Date(editedTaskData.date_fin).toISOString() : null,
        est_terminee: editedTaskData.statut === 'terminée',
        importance: Number(editedTaskData.importance),
        duree_estimee: editedTaskData.duree_estimee ? Number(editedTaskData.duree_estimee) : null,
        duree_reelle: editedTaskData.duree_reelle ? Number(editedTaskData.duree_reelle) : null,
        seance_etude_id: isLinkedToActiveSeance ? activeSeanceId : null,
      };

      await onUpdateTask(editedTaskData.id, payload);
      onClose();
    } catch (error) {
      showSnackbar(`Erreur lors de l'enregistrement: ${error.message}`, "error");
      console.error("Erreur lors de l'enregistrement de la tâche:", error);
    }
  };

  if (!taskDetails) return null;

  // Use theme colors for the input styles
  const inputSx = {
    borderRadius: '8px',
    bgcolor: alpha(theme.palette.glass.inner, 0.8),
    color: theme.palette.text.primary,
    '& .MuiFilledInput-root': {
      borderRadius: '8px',
      bgcolor: alpha(theme.palette.glass.inner, 0.8),
      '&:hover': { bgcolor: alpha(theme.palette.glass.inner, 0.9) + ' !important' },
      '&.Mui-focused': { bgcolor: alpha(theme.palette.glass.inner, 0.9) + ' !important' },
      color: theme.palette.text.primary,
    },
    disableUnderline: true,
  };

  // Use theme colors for the input label styles
  const inputLabelSx = {
    color: theme.palette.text.secondary,
    fontWeight: 'medium',
  };

  // Re-write ReadOnlyPill to use theme colors
  const ReadOnlyPill = ({ label, value, icon }) => (
    <Box
      sx={{
        bgcolor: theme.palette.glass.inner,
        backdropFilter: 'blur(5px)',
        border: `1px solid ${theme.palette.glass.innerBorder}`,
        borderRadius: '8px',
        p: '12px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: 1,
        boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
        color: theme.palette.text.primary,
        width: '100%',
        minHeight: '56px',
        boxSizing: 'border-box',
        justifyContent: 'flex-start',
      }}
    >
      {icon && React.cloneElement(icon, { sx: { fontSize: 24, color: theme.palette.text.secondary, flexShrink: 0 } })}
      <Typography variant="body2" fontWeight="bold" sx={{ color: theme.palette.text.secondary, flexShrink: 0, mr: 0.5 }}>
        {label}:
      </Typography>
      <Typography variant="body1" sx={{ color: theme.palette.text.primary, flexGrow: 1, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {value}
      </Typography>
    </Box>
  );

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          backgroundColor: theme.palette.glass.outer,
          backdropFilter: 'blur(12px)',
          border: `1px solid ${theme.palette.glass.outerBorder}`,
          borderRadius: '16px',
          boxShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.15)',
          color: theme.palette.text.primary,
        }
      }}
    >
      <DialogTitle sx={{ fontWeight: 'bold', textAlign: 'center', pb: 1, color: theme.palette.text.primary }}>
        Modifier la tâche
        <Typography variant="subtitle1" color="text.secondary">"{taskDetails.titre}"</Typography>
      </DialogTitle>
      <DialogContent
        dividers
        sx={{
          pt: 2,
          pb: 2,
          display: 'flex',
          flexDirection: { xs: 'column', md: 'row' },
          gap: { xs: 2, md: 3 },
          alignItems: 'flex-start',
          overflowY: 'auto',
        }}
      >
        <Box sx={{ flexBasis: { xs: '100%', md: 'calc(66.66% - 16px)' }, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <TextField
            margin="normal"
            name="titre"
            label="Titre de la tâche"
            type="text"
            fullWidth
            variant="filled"
            value={editedTaskData.titre || ''}
            onChange={handleFieldChange}
            InputProps={{ disableUnderline: true, sx: inputSx }}
            InputLabelProps={{ sx: inputLabelSx }}
          />
          <TextField
            margin="normal"
            name="description"
            label="Description"
            type="text"
            fullWidth
            multiline
            rows={3}
            variant="filled"
            value={editedTaskData.description || ''}
            onChange={handleFieldChange}
            InputProps={{ disableUnderline: true, sx: inputSx }}
            InputLabelProps={{ sx: inputLabelSx }}
          />

          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal" variant="filled" sx={{ ...inputSx, minWidth: 150 }}> {/* Added minWidth */}
                <InputLabel>Importance</InputLabel>
                <Select
                  name="importance"
                  value={editedTaskData.importance || ''}
                  onChange={handleFieldChange}
                  label="Importance"
                  disableUnderline
                  sx={{ color: theme.palette.text.primary }}
                  inputProps={{ sx: { borderRadius: '8px' } }}
                  MenuProps={{
                    PaperProps: {
                      sx: {
                        bgcolor: theme.palette.glass.inner,
                        backdropFilter: 'blur(10px)',
                        border: `1px solid ${theme.palette.glass.innerBorder}`,
                      },
                    },
                  }}
                >
                  {[1, 2, 3, 4, 5].map((importance) => (
                    <MenuItem key={importance} value={importance}>
                      {getImportanceDisplay(importance).label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal" variant="filled" sx={{ ...inputSx, minWidth: 150 }}> {/* Added minWidth */}
                <InputLabel>Statut</InputLabel>
                <Select
                  name="statut"
                  value={editedTaskData.statut || ''}
                  onChange={handleFieldChange}
                  label="Statut"
                  disableUnderline
                  sx={{ color: theme.palette.text.primary }}
                  inputProps={{ sx: { borderRadius: '8px' } }}
                  MenuProps={{
                    PaperProps: {
                      sx: {
                        bgcolor: theme.palette.glass.inner,
                        backdropFilter: 'blur(10px)',
                        border: `1px solid ${theme.palette.glass.innerBorder}`,
                      },
                    },
                  }}
                >
                  <MenuItem value="en attente">En attente</MenuItem>
                  <MenuItem value="en cours">En cours</MenuItem>
                  <MenuItem value="terminée">Complétée</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>

          <TextField
            margin="normal"
            name="date_fin"
            label="Date de fin (optionnel)"
            type="date"
            fullWidth
            variant="filled"
            value={editedTaskData.date_fin || ''}
            onChange={handleFieldChange}
            InputLabelProps={{ shrink: true, sx: inputLabelSx }}
            InputProps={{ disableUnderline: true, sx: inputSx }}
          />
          <TextField
            margin="normal"
            name="duree_estimee"
            label="Durée Estimée (s)"
            type="number"
            fullWidth
            variant="filled"
            value={editedTaskData.duree_estimee || ''}
            onChange={handleFieldChange}
            InputLabelProps={{ sx: inputLabelSx }}
            InputProps={{ disableUnderline: true, sx: inputSx }}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={isLinkedToActiveSeance}
                onChange={handleCheckboxChange}
                name="link_to_active_seance"
                disabled={!activeSeanceId || (taskDetails.seance_etude_id === activeSeanceId && isLinkedToActiveSeance)}
                sx={{
                  color: theme.palette.secondary.main,
                  '&.Mui-checked': {
                    color: theme.palette.secondary.main,
                  },
                }}
              />
            }
            label="Ajouter à la séance active"
            sx={{
              color: theme.palette.text.secondary,
              mt: 1,
              '& .MuiTypography-root': { fontWeight: 'medium' }
            }}
          />
        </Box>

        <Box sx={{ flexBasis: { xs: '100%', md: 'calc(33.33% - 16px)' }, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <ReadOnlyPill label="Priorité" value={editedTaskData.priorite || 'N/A'} icon={<PriorityHighIcon />} />
          <ReadOnlyPill label="Est Terminée" value={editedTaskData.est_terminee ? 'Oui' : 'Non'} icon={<CheckCircleOutlineIcon />} />
          <ReadOnlyPill label="Date de création" value={editedTaskData.date_creation ? new Date(editedTaskData.date_creation).toLocaleDateString() : 'N/A'} icon={<CalendarTodayIcon />} />
          <ReadOnlyPill label="Date de début" value={editedTaskData.date_debut ? new Date(editedTaskData.date_debut).toLocaleDateString() : 'N/A'} icon={<CalendarTodayIcon />} />
          <ReadOnlyPill label="Durée Réelle" value={editedTaskData.duree_reelle ? `${editedTaskData.duree_reelle}s` : 'N/A'} icon={<TimerIcon />} />
        </Box>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2, justifyContent: 'center', gap: 2 }}>
        <Button onClick={onClose} sx={{ color: theme.palette.text.secondary }}>Annuler</Button>
        <Button
          onClick={handleSave}
          variant="contained"
          sx={{
            bgcolor: alpha(theme.palette.secondary.main, 0.5),
            '&:hover': { bgcolor: alpha(theme.palette.secondary.main, 0.7) },
            borderRadius: '8px'
          }}
        >
          Enregistrer
        </Button>
      </DialogActions>
    </Dialog>
  );
}