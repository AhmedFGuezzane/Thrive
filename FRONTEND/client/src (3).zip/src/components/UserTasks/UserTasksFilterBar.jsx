import React from 'react';
import {
  Box,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  InputAdornment,
  IconButton,
  CircularProgress,
  useTheme, // <-- ADDED useTheme hook
} from "@mui/material";
import { alpha } from '@mui/material/styles'; // <-- ADDED alpha utility
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import AddIcon from '@mui/icons-material/Add';

export default function UserTasksFilterBar({
  searchTerm,
  setSearchTerm,
  selectedImportance,
  setSelectedImportance,
  taskViewMode,
  setTaskViewMode,
  activeSeanceExists,
  onAddTaskClick,
  onRefreshClick,
  loading,
  getImportanceDisplay,
}) {
  const theme = useTheme();

  // Reusable style for the bordered buttons
  const borderedButtonStyle = {
    color: theme.palette.primary.main,
    bgcolor: alpha(theme.palette.glass.inner, 0.7),
    borderRadius: '8px',
    border: `1px solid ${alpha(theme.palette.glass.innerBorder, 0.7)}`,
    p: '8px',
    '&:hover': {
      bgcolor: alpha(theme.palette.glass.inner, 0.9),
      borderColor: theme.palette.primary.main, // Primary color border on hover
    },
    transition: theme.transitions.create(['background-color', 'border-color']),
  };

  // Reusable style for the form controls (TextField, Select)
  const formControlStyle = {
    flexGrow: 1,
    minWidth: '150px',
    bgcolor: alpha(theme.palette.glass.inner, 0.7),
    borderRadius: '8px',
    '& .MuiOutlinedInput-root': {
      borderRadius: '8px',
      '& fieldset': { borderColor: alpha(theme.palette.glass.innerBorder, 0.7) },
      '&:hover fieldset': { borderColor: theme.palette.primary.main },
      '&.Mui-focused fieldset': { borderColor: theme.palette.primary.main },
      color: theme.palette.text.primary,
    },
    '& .MuiInputLabel-root': { color: theme.palette.text.secondary },
    flexShrink: 0,
  };

  return (
    <Box
      sx={{
        width: '100%',
        mb: 3,
        p: 1.5,
        // Use generic inner glass properties for the container
        bgcolor: theme.palette.glass.inner,
        backdropFilter: 'blur(10px)',
        border: `1px solid ${theme.palette.glass.innerBorder}`,
        borderRadius: '8px',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
        display: 'flex',
        flexDirection: { xs: 'column', sm: 'row' },
        gap: 1.5,
        alignItems: 'center',
        flexWrap: 'wrap',
        flexShrink: 0,
      }}
    >
      <TextField
        fullWidth={false}
        variant="outlined"
        size="small"
        placeholder="Rechercher tâche..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{
          ...formControlStyle, // Apply reusable style
          '& .MuiInputBase-input::placeholder': { color: theme.palette.text.secondary },
        }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon sx={{ color: theme.palette.text.secondary }} />
            </InputAdornment>
          ),
        }}
      />
      <FormControl
        variant="outlined"
        size="small"
        sx={{
          ...formControlStyle, // Apply reusable style
          minWidth: 120,
        }}
      >
        <InputLabel>Importance</InputLabel>
        <Select
          value={selectedImportance}
          onChange={(e) => setSelectedImportance(e.target.value)}
          label="Importance"
          MenuProps={{
            PaperProps: {
              sx: {
                bgcolor: theme.palette.glass.inner,
                backdropFilter: 'blur(10px)',
                border: `1px solid ${theme.palette.glass.innerBorder}`,
              },
            },
          }}
        >
          <MenuItem value="">Toutes</MenuItem>
          {[1, 2, 3, 4, 5].map((importance) => (
            <MenuItem key={importance} value={importance}>
              {getImportanceDisplay(importance).label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <FormControl
        variant="outlined"
        size="small"
        sx={{
          ...formControlStyle, // Apply reusable style
          minWidth: 120,
        }}
      >
        <InputLabel>Mode Vue</InputLabel>
        <Select
          value={taskViewMode}
          onChange={(e) => setTaskViewMode(e.target.value)}
          label="Mode Vue"
          MenuProps={{
            PaperProps: {
              sx: {
                bgcolor: theme.palette.glass.inner,
                backdropFilter: 'blur(10px)',
                border: `1px solid ${theme.palette.glass.innerBorder}`,
              },
            },
          }}
        >
          <MenuItem value="all_tasks">Toutes les tâches</MenuItem>
          <MenuItem value="current_seance" disabled={!activeSeanceExists}>
            Tâches de la séance active
          </MenuItem>
        </Select>
      </FormControl>

      <IconButton
        onClick={onAddTaskClick}
        sx={borderedButtonStyle}
      >
        <AddIcon fontSize="small" />
      </IconButton>
      <IconButton
        onClick={onRefreshClick}
        disabled={loading}
        sx={borderedButtonStyle}
      >
        {loading ? (<CircularProgress size={20} sx={{ color: theme.palette.primary.main }} />) : (<RefreshIcon fontSize="small" />)}
      </IconButton>
    </Box>
  );
}