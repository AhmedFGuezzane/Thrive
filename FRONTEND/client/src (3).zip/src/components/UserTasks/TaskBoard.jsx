import React from 'react';
import { Box, Typography, useTheme } from "@mui/material"; // ADDED useTheme
import { alpha } from '@mui/material/styles'; // ADDED alpha
import { Droppable } from '@hello-pangea/dnd';
import TaskCard from './TaskCard'; // Import the new TaskCard component

export default function TaskBoard({ displayedTasks, onViewDetailsClick, getImportanceDisplay, getStatusDisplay }) {
  const theme = useTheme(); // Use the theme hook
  
  // getListStyle is now a function that takes isDraggingOver
  const getListStyle = (isDraggingOver) => ({
    // Use theme colors for background and border based on theme mode and drag state
    background: isDraggingOver 
      ? alpha(theme.palette.secondary.main, 0.2) // A translucent accent color when dragging over
      : theme.palette.glass.inner, // Use the inner glass color when not dragging
    padding: '8px',
    borderRadius: '12px',
    flexGrow: 1,
    minHeight: '100px',
    overflowY: 'auto',
    scrollbarWidth: 'none',
    '&::-webkit-scrollbar': { display: 'none' },
    msOverflowStyle: 'none',
    display: 'flex',
    flexDirection: 'column',
  });

  return (
    <>
      {Object.entries(displayedTasks).map(([columnId, columnTasks]) => (
        <Droppable key={columnId} droppableId={columnId}>
          {(provided, snapshot) => (
            <Box
              ref={provided.innerRef}
              style={getListStyle(snapshot.isDraggingOver)}
              {...provided.droppableProps}
              sx={{
                // Use the inner glass border color from the theme
                border: `1px solid ${theme.palette.glass.innerBorder}`,
                boxShadow: '0 2px 15px rgba(0, 0, 0, 0.08)',
                display: 'flex',
                flexDirection: 'column',
                flexBasis: '33%',
                minWidth: '200px',
                p: 2,
                overflowY: 'auto',
                scrollbarWidth: 'none',
                '&::-webkit-scrollbar': { display: 'none' },
                msOverflowStyle: 'none',
              }}
            >
              <Typography
                variant="h6"
                fontWeight="bold"
                // Use the heading color from the glass palette
                color={theme.palette.glass.heading}
                mb={2}
                sx={{ textTransform: 'capitalize' }}
              >
                {columnId.replace('en attente', 'En attente').replace('en cours', 'En cours').replace('terminée', 'Terminée')}
              </Typography>
              {columnTasks.length === 0 && (
                <Typography
                  variant="body2"
                  // Use the secondary text color for a subtle look
                  color={theme.palette.text.secondary}
                  sx={{ textAlign: 'center', p: 2 }}
                >
                  Aucune tâche ici.
                </Typography>
              )}
              {columnTasks.map((task, index) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  index={index}
                  onViewDetailsClick={onViewDetailsClick}
                  getImportanceDisplay={getImportanceDisplay}
                  getStatusDisplay={getStatusDisplay}
                />
              ))}
              {provided.placeholder}
            </Box>
          )}
        </Droppable>
      ))}
    </>
  );
}