// src/components/UserSeance/SeanceDetailsCard.jsx
import React, { useContext } from 'react';
import { Box, Typography, Grid, Divider, useTheme } from '@mui/material';
import { TimerContext } from '../../contexts/TimerContext';
import ConfirmationItem from '../common/ConfirmationItem';
import DisplayCard from '../common/DisplayCard';

import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import HourglassTopIcon from '@mui/icons-material/HourglassTop';
import TuneIcon from '@mui/icons-material/Tune';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';

export default function SeanceDetailsCard() {
  const { pomodoroConfig } = useContext(TimerContext);
  const theme = useTheme();

  if (!pomodoroConfig) {
    return null; // Don't render if there's no active seance
  }

  const formatTime = (totalSeconds) => {
    if (isNaN(totalSeconds) || totalSeconds < 0) return '0s';
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    let parts = [];
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (seconds > 0 || parts.length === 0) parts.push(`${seconds}s`);

    return parts.join(' ');
  };

  // You will also need to update your DisplayCard and ConfirmationItem components to use the theme's colors.
  // Assuming they are located in `../common/`, here is how you would style them with the theme.

  // A standalone DisplayCard component using the theme
  const ThemedDisplayCard = ({ title, icon, children }) => (
    <Box
      sx={{
        borderRadius: '12px',
        p: 2,
        mb: 2,
        // Use inner glass properties for the card background
        bgcolor: theme.palette.glass.inner,
        backdropFilter: 'blur(10px)',
        border: `1px solid ${theme.palette.glass.innerBorder}`,
        boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
      }}
    >
      <Box display="flex" alignItems="center" mb={2}>
        {React.cloneElement(icon, { sx: { color: theme.palette.glass.heading, fontSize: 24, mr: 1 } })}
        <Typography variant="h6" fontWeight="bold" sx={{ color: theme.palette.glass.heading }}>
          {title}
        </Typography>
      </Box>
      <Divider sx={{ mb: 2, borderColor: theme.palette.glass.innerBorder }} />
      {children}
    </Box>
  );

  // A standalone ConfirmationItem component using the theme
  const ThemedConfirmationItem = ({ label, value }) => (
    <Box display="flex" justifyContent="space-between" mb={1} alignItems="center">
      <Typography variant="body2" sx={{ color: theme.palette.glass.body, fontWeight: 'medium' }}>
        {label}:
      </Typography>
      <Typography variant="body1" sx={{ color: theme.palette.text.primary, fontWeight: 'bold' }}>
        {String(value)}
      </Typography>
    </Box>
  );


  return (
    <Box
      sx={{
        borderRadius: '16px',
        p: 3,
        // Use outer glass properties for the main container
        bgcolor: theme.palette.glass.outer,
        backdropFilter: 'blur(10px)',
        border: `1px solid ${theme.palette.glass.outerBorder}`,
        boxShadow: '0 6px 20px rgba(0, 0, 0, 0.1)',
        overflowY: 'auto',
        width: '100%',
        height:'100%',
        boxSizing: 'border-box',
        color: theme.palette.text.primary,
        // Dynamic scrollbar styles
        '&::-webkit-scrollbar': { width: '8px' },
        '&::-webkit-scrollbar-thumb': {
            backgroundColor: theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.2)',
            borderRadius: '10px',
        },
        '&::-webkit-scrollbar-thumb:hover': {
            backgroundColor: theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.4)' : 'rgba(0, 0, 0, 0.4)',
        },
        scrollbarWidth: 'thin',
      }}
    >
      <Grid container spacing={3} alignItems="stretch" justifyContent='space-between'>
        {/* Durations Card */}
        <Grid item xs={12}>
          <ThemedDisplayCard title="Durées" icon={<HourglassTopIcon />}>
            <ThemedConfirmationItem label="Séance" value={formatTime(pomodoroConfig.duree_seance)} />
            <ThemedConfirmationItem label="Pause courte" value={formatTime(pomodoroConfig.duree_pause_courte)} />
            <ThemedConfirmationItem label="Pause longue" value={formatTime(pomodoroConfig.duree_pause_longue)} />
            <ThemedConfirmationItem label="Durée Totale" value={formatTime(pomodoroConfig.duree_seance_totale)} />
          </ThemedDisplayCard>
        </Grid>
        
        {/* General Details Card */}
        <Grid item xs={12}>
          <ThemedDisplayCard title="Détails" icon={<InfoOutlinedIcon />}>
            <ThemedConfirmationItem label="Type de séance" value={pomodoroConfig.type_seance} />
            <ThemedConfirmationItem label="Nom de la séance" value={pomodoroConfig.nom_seance} />
            <ThemedConfirmationItem label="Nom préconfiguration" value={pomodoroConfig.nom_preconfiguration} />
            <ThemedConfirmationItem label="Thème" value={pomodoroConfig.theme} />
          </ThemedDisplayCard>
        </Grid>
        
        {/* Alerts and Automation Card */}
        <Grid item xs={12}>
          <ThemedDisplayCard title="Alertes et Automatisation" icon={<NotificationsActiveIcon />}>
            <Grid container spacing={2}>
              <Grid item xs={6} sm={4}><ThemedConfirmationItem label="Démarrage auto" value={pomodoroConfig.auto_demarrage ? 'Oui' : 'Non'} /></Grid>
              <Grid item xs={6} sm={4}><ThemedConfirmationItem label="Alerte sonore" value={pomodoroConfig.alerte_sonore ? 'Oui' : 'Non'} /></Grid>
              <Grid item xs={6} sm={4}><ThemedConfirmationItem label="Notification" value={pomodoroConfig.notification ? 'Oui' : 'Non'} /></Grid>
              <Grid item xs={6} sm={4}><ThemedConfirmationItem label="Vibration" value={pomodoroConfig.vibration ? 'Oui' : 'Non'} /></Grid>
              <Grid item xs={6} sm={4}><ThemedConfirmationItem label="Suivi du temps total" value={pomodoroConfig.suivi_temps_total ? 'Oui' : 'Non'} /></Grid>
            </Grid>
          </ThemedDisplayCard>
        </Grid>
      </Grid>
    </Box>
  );
}