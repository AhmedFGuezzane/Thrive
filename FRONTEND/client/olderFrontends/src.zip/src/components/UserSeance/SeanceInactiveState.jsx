// src/components/UserSeance/SeanceInactiveState.jsx
import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

export default function SeanceInactiveState({ onCreateSeanceClick }) {
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '80vh',
        width: '65%', // Adjusted to be 65% of the parent width
        maxWidth: '800px', // Added a maximum width to prevent it from getting too wide on large screens
        margin: 'auto',
        gap: 3,
        p: 5,
        // --- Refined Glassmorphism styles ---
        bgcolor: 'rgba(255, 255, 255, 0.2)',
        backdropFilter: 'blur(25px) saturate(180%)',
        border: '1px solid rgba(255, 255, 255, 0.4)',
        borderRadius: '24px',
        boxShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.2)',
        transition: 'all 0.5s cubic-bezier(0.22, 1, 0.36, 1)',
        '&:hover': {
          boxShadow: '0 12px 48px 0 rgba(0, 0, 0, 0.3)',
          transform: 'scale(1.02) perspective(1000px) rotateX(2deg)',
        },
      }}
    >
      <Typography variant="h3" fontWeight={800} sx={{ color: 'rgba(0, 0, 0, 0.85)', textShadow: '0 1px 3px rgba(255,255,255,0.6)' }}>
        Aucune séance active
      </Typography>
      <Typography variant="h5" sx={{ color: 'rgba(0, 0, 0, 0.6)', textAlign: 'center', mb: 2 }}>
        Commencez une nouvelle session pour suivre votre progression !
      </Typography>
      <Button
        variant="contained"
        onClick={onCreateSeanceClick}
        sx={{
          background: 'linear-gradient(145deg, #00c6ff, #0072ff)',
          color: '#ffffff',
          fontWeight: 'bold',
          borderRadius: '12px',
          px: 2.5, // Reduced horizontal padding
          py: 1, // Reduced vertical padding
          fontSize: '1rem', // Further reduced font size
          boxShadow: '0 4px 15px rgba(0, 114, 255, 0.4)',
          transition: 'all 0.4s cubic-bezier(0.22, 1, 0.36, 1)',
          '&:hover': {
            transform: 'translateY(-3px) scale(1.05)',
            boxShadow: '0 8px 25px rgba(0, 114, 255, 0.6)',
            background: 'linear-gradient(145deg, #0093ff, #004dff)',
          },
          '&:active': {
            transform: 'translateY(-1px) scale(0.98)',
            boxShadow: '0 2px 10px rgba(0, 114, 255, 0.3)',
          },
        }}
        startIcon={<AddIcon sx={{ fontSize: '1.25rem' }} />}
      >
        Créer une séance
      </Button>
    </Box>
  );
}