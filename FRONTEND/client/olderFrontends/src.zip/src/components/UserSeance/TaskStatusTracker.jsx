// src/components/UserSeance/TaskStatusTracker.jsx
import React, { useState, useEffect, useContext } from 'react';
import { Box, Typography, CircularProgress, Grid } from '@mui/material';
import { TimerContext } from '../../contexts/TimerContext';
import { fetchTasksBySeanceId } from '../../utils/taskService.jsx';
import { getStatusDisplay } from '../../utils/taskUtils.js';

export default function TaskStatusTracker() {
    const { activeSeanceId } = useContext(TimerContext);
    const [taskCounts, setTaskCounts] = useState({ 'en attente': 0, 'en cours': 0, 'terminée': 0 });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchAndCountTasks = async () => {
            if (!activeSeanceId) {
                setTaskCounts({ 'en attente': 0, 'en cours': 0, 'terminée': 0 });
                setLoading(false);
                return;
            }

            setLoading(true);
            try {
                const tasks = await fetchTasksBySeanceId(activeSeanceId);
                const counts = tasks.reduce((acc, task) => {
                    const status = String(task.statut).toLowerCase();
                    if (status === 'en attente') {
                        acc['en attente']++;
                    } else if (status === 'en cours') {
                        acc['en cours']++;
                    } else if (['terminée', 'complétée', 'complete'].includes(status)) {
                        acc['terminée']++;
                    }
                    return acc;
                }, { 'en attente': 0, 'en cours': 0, 'terminée': 0 });
                setTaskCounts(counts);
            } catch (error) {
                console.error("Failed to fetch tasks for the session:", error);
                setTaskCounts({ 'en attente': 0, 'en cours': 0, 'terminée': 0 });
            } finally {
                setLoading(false);
            }
        };

        fetchAndCountTasks();
    }, [activeSeanceId]);

    const statusOrder = ['en attente', 'en cours', 'terminée'];

    return (
        <Box
            sx={{
                width: '24rem',
                height:'98%',
                p: 2,
                borderRadius: '16px',
                bgcolor: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
                mt: 1.5,
            }}
        >
            <Typography variant="h6" fontWeight="bold" gutterBottom>
                Progression des tâches
            </Typography>
            {loading ? (
                <Box display="flex" justifyContent="center" alignItems="center" height="50%">
                    <CircularProgress size={30} />
                </Box>
            ) : (
                <Grid mt={5} display="flex" flexDirection="column" container spacing={2} justifyContent="space-around">
                    {statusOrder.map(status => {
                        const display = getStatusDisplay(status); //
                        return (
                            <Grid item xs={4} key={status}>
                                <Box
                                    sx={{
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        p: 2,
                                        borderRadius: '12px',
                                        bgcolor: 'rgba(255, 255, 255, 0.2)',
                                        border: '1px solid rgba(255, 255, 255, 0.3)',
                                    }}
                                >
                                    <Typography variant="h5" fontWeight="bold" sx={{ color: display.bgColor }}>
                                        {taskCounts[status]}
                                    </Typography>
                                    <Typography variant="body2" sx={{ color: '#555', mt: 0.5 }}>
                                        {display.label}
                                    </Typography>
                                </Box>
                            </Grid>
                        );
                    })}
                </Grid>
            )}
        </Box>
    );
}