// src/pages/user/UserSeance.jsx

import React, { useState, useContext } from 'react';
import { Box, Typography, Grid, useTheme } from '@mui/material'; // <-- ADDED useTheme hook
import { TimerContext } from '../../contexts/TimerContext';
import SeanceDetailsCard from '../../components/UserSeance/SeanceDetailsCard';
import TimerDisplayCard from '../../components/UserSeance/TimerDisplayCard';
import SeanceInactiveState from '../../components/UserSeance/SeanceInactiveState';
import TaskStatusTracker from '../../components/UserSeance/TaskStatusTracker';
import UrgentTasksCard from '../../components/UserSeance/UrgentTasksCard.jsx';
import CreateSeanceDialog from '../../components/common/CreateSeanceDialog';
import SnackbarAlert from '../../components/common/SnackbarAlert';
import PhaseTransitionDialog from '../../components/common/PhaseTransitionDialog'; // <-- RESTORED original import path
import { createSeance } from '../../utils/seanceService.jsx';
import TimerBar from '../../components/common/TimerBar.jsx';

export default function UserSeance() {
    // Use the global theme hook to access the palette
    const theme = useTheme();

    const { activeSeanceId, startSeance, phase, loaded } = useContext(TimerContext);

    // --- REPLACED HARDCODED COLORS WITH DYNAMIC THEME PALETTE COLORS ---
    // The background for a glassmorphism card should be the 'paper' color from the theme
    const glassPageBg = theme.palette.background.paper;
    // The border color should be dynamic for better visibility in light/dark mode
    const glassBorderColor = theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
    // ----------------------------------------------------------------------

    // Dialog and form state for creating a new seance
    const [dialogOpen, setDialogOpen] = useState(false);
    const [activeStep, setActiveStep] = useState(0);
    const [formData, setFormData] = useState({
        type_seance: "focus",
        nom: "Deep Work Session",
        pomodoro: {
            duree_seance: 1500,
            duree_pause_courte: 300,
            duree_pause_longue: 900,
            nbre_pomodoro_avant_pause_longue: 4,
            duree_seance_totale: 7200,
            auto_demarrage: true,
            alerte_sonore: true,
            notification: true,
            vibration: false,
            nom_seance: "Pomodoro Config A",
            theme: "dark",
            suivi_temps_total: true,
            nom_preconfiguration: "Standard Focus"
        }
    });

    // Snackbar state
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('info');
    const [snackbarLoading, setSnackbarLoading] = useState(false);

    const showSnackbar = (message, severity, loading = false) => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarLoading(loading);
        setSnackbarOpen(true);
    };

    const handleSnackbarClose = (_, reason) => {
        if (reason === 'clickaway') return;
        setSnackbarOpen(false);
        setSnackbarLoading(false);
    };

    const handleDialogOpen = () => setDialogOpen(true);
    const handleDialogClose = () => {
        setDialogOpen(false);
        setTimeout(() => setActiveStep(0), 300);
    };

    const handleFormChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handlePomodoroChange = (e) => {
        const { name, value, type, checked } = e.target;
        const newValue = type === 'checkbox' ? checked : (type === 'number' ? Number(value) : value);
        setFormData(prev => ({
            ...prev,
            pomodoro: { ...prev.pomodoro, [name]: newValue }
        }));
    };

    const handleSubmit = async () => {
        showSnackbar('Création de votre session...', 'info', true);

        try {
            const createdSeance = await createSeance(formData);
            let newSeanceId = createdSeance?.id || null;
            if (!newSeanceId) {
                console.warn("Created seance object did not contain an ID directly:", createdSeance);
                showSnackbar('Session créée, mais ID non reçu. Veuillez rafraîchir.', 'warning');
            }
            showSnackbar('Session créée avec succès !', 'success');
            startSeance(formData.pomodoro, newSeanceId);
            handleDialogClose();
        } catch (err) {
            showSnackbar(`Erreur lors de la création de la session : ${err.message}`, 'error');
        }
    };

    // Timer Context handlers for the phase transition dialog
    const { startBreak, resumeStudy } = useContext(TimerContext);
    const showDialog = loaded && (phase === 'awaiting_break' || phase === 'awaiting_study');
    const handleDialogConfirm = () => {
        if (phase === 'awaiting_break') startBreak();
        else if (phase === 'awaiting_study') resumeStudy();
    };

    return (
        <Box
            width="98%"
            height="100%"
            mx="auto"
            sx={{
                // --- UPDATED to use dynamic theme colors and corrected a typo ---
                backgroundColor: glassPageBg, // Corrected from "glassPageBg" string to the variable
                backdropFilter: 'blur(8px)',
                border: `1px solid ${glassBorderColor}`,
                boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
                borderRadius: '16px',
                p: 3,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                color: theme.palette.text.primary, // <-- Use theme text color for contrast
                position: 'relative',
                overflowY: 'auto',
                scrollbarWidth: 'none',
                '&::-webkit-scrollbar': {
                    display: 'none',
                },
            }}
        >
            <Box flexGrow={1} display="flex" flexDirection="column" height="100%" width="100%" alignItems="center" justifyContent="center" gap={"1rem"} >
                {activeSeanceId ? (
                    <>
                        <Grid container spacing={2} display="flex" sx={{ width: '100%', height: '100%' }}>
                            {/* Left Side: Timer and Info Cards */}
                            <Grid width="72%" height="88%">
                                <Box
                                    display="flex"
                                    flexDirection="column"
                                    gap={3}
                                    height="100%"
                                    sx={{
                                        p: 2,
                                        borderRadius: '16px',
                                        // --- UPDATED to use dynamic theme color ---
                                        bgcolor: theme.palette.background.paper,
                                        backdropFilter: 'blur(10px)',
                                        border: `1px solid ${glassBorderColor}`, // Use the same dynamic border color
                                        boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
                                        alignItems: 'start',
                                        justifyContent: 'center',
                                    }}
                                >
                                    <TimerDisplayCard />
                                    {/* NEW: Add the Task Status Tracker component here */}
                                    <Box display="flex" width="100%" height = "100%" justifyContent="space-between" gap={"1rem"}>
                                        <TaskStatusTracker />
                                        <UrgentTasksCard />

                                    </Box>

                                </Box>

                                {activeSeanceId && (
                                    <Box sx={{ flexShrink: 0, width: '100%', display: 'flex', justifyContent: 'center' }}>
                                        <TimerBar onCreateClick={handleDialogOpen} config={formData.pomodoro} />
                                    </Box>
                                )}

                            </Grid>

                            {/* Right Side: Configuration */}
                            <Grid width="25%" height="100%">
                                <SeanceDetailsCard />
                            </Grid>
                        </Grid>
                    </>
                ) : (
                    <SeanceInactiveState onCreateSeanceClick={handleDialogOpen} />
                )}
            </Box>


            {/* Dialogs and Snackbar */}
            <CreateSeanceDialog
                open={dialogOpen}
                onClose={handleDialogClose}
                activeStep={activeStep}
                setActiveStep={setActiveStep}
                formData={formData}
                setFormData={setFormData}
                handleFormChange={handleFormChange}
                handlePomodoroChange={handlePomodoroChange}
                handleSubmit={handleSubmit}
            />

            <SnackbarAlert
                open={snackbarOpen}
                message={snackbarMessage}
                severity={snackbarSeverity}
                loading={snackbarLoading}
                onClose={handleSnackbarClose}
            />

            <PhaseTransitionDialog
                open={showDialog}
                phase={phase}
                onConfirm={handleDialogConfirm}
            />
        </Box>
    );
}