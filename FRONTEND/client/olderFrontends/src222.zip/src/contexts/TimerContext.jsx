// src/contexts/TimerContext.jsx
import React, { createContext, useState, useEffect, useRef } from 'react';
import { endSeance } from '../utils/seanceService'; // <-- IMPORT THE NEW FUNCTION

export const TimerContext = createContext();

export const TimerProvider = ({ children }) => {
  const [phase, setPhase] = useState('idle');
  const [isPaused, setIsPaused] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [timeElapsedTotal, setTimeElapsedTotal] = useState(0);
  const [pomodoroConfig, setPomodoroConfig] = useState(null);
  const [pomodoroCount, setPomodoroCount] = useState(0);
  const [interruptions, setInterruptions] = useState(0); // <-- ADDED state to track interruptions
  const intervalRef = useRef(null);
  const [upcomingBreakType, setUpcomingBreakType] = useState('courte');
  const [loaded, setLoaded] = useState(false);

  // State to store the active seance ID
  const [activeSeanceId, setActiveSeanceId] = useState(null);

  const clearTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    intervalRef.current = null;
  };

  useEffect(() => {
    if ((phase === 'study' || phase === 'break') && !isPaused && timeLeft > 0) {
      clearTimer();

      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          const newTime = prev - 1;
          if (newTime <= 0) {
            clearTimer();
            if (phase === 'study') {
              setPhase('awaiting_break');
              setPomodoroCount((p) => p + 1);
            } else if (phase === 'break') {
              setPhase('awaiting_study');
            }
            return 0;
          }
          return newTime;
        });
        setTimeElapsedTotal((prev) => prev + 1);
      }, 1000);
    } else {
      clearTimer();
    }
    return () => clearTimer();
  }, [phase, isPaused, timeLeft]);

  const beginPhase = (newPhase, duration, pausedState = false) => {
    setPhase(newPhase);
    setTimeLeft(duration);
    setIsPaused(pausedState);
  };

  // UPDATED: startSeance now accepts seanceId
  const startSeance = (config, seanceId) => {
    setPomodoroConfig(config);
    setPomodoroCount(0);
    setTimeElapsedTotal(0);
    setInterruptions(0); // <-- Reset interruptions on start
    setUpcomingBreakType('courte');
    setActiveSeanceId(seanceId); // Store the active seance ID
    beginPhase('study', config.duree_seance);
  };

  const startBreak = () => {
    if (!pomodoroConfig) return;
    const { duree_pause_courte, duree_pause_longue, nbre_pomodoro_avant_pause_longue } = pomodoroConfig;

    const isLong = pomodoroCount % nbre_pomodoro_avant_pause_longue === 0 && pomodoroCount !== 0;
    setUpcomingBreakType(isLong ? 'longue' : 'courte');

    const duration = isLong ? duree_pause_longue : duree_pause_courte;
    beginPhase('break', duration);
  };

  const resumeStudy = () => {
    if (!pomodoroConfig) return;
    if (pomodoroConfig.duree_seance_totale > 0 && timeElapsedTotal >= pomodoroConfig.duree_seance_totale) {
      setPhase('completed');
      clearTimer();
      return;
    }
    beginPhase('study', pomodoroConfig.duree_seance);
  };

  const stopSeance = async () => {
    // Check if there is an active seance to end
    if (activeSeanceId) {
      try {
        const seanceData = {
          duree_reelle: timeElapsedTotal,
          nbre_pomodoro_effectues: pomodoroCount,
          interruptions: interruptions,
          est_complete: true,
          statut: 'terminee',
        };

        // Make the API call to end the seance and wait for it to complete
        const response = await endSeance(activeSeanceId, seanceData);
        console.log('Séance terminée avec succès:', response);

      } catch (error) {
        console.error("Erreur lors de la fin de la séance :", error);
        // You can add a Snackbar alert here if you have access to a showSnackbar function.
      }
    }

    // Reset the timer and state regardless of the API call's success
    clearTimer();
    setPhase('idle');
    setTimeLeft(0);
    setIsPaused(false);
    setPomodoroCount(0);
    setPomodoroConfig(null);
    setTimeElapsedTotal(0);
    setInterruptions(0);
    setUpcomingBreakType('courte');
    setActiveSeanceId(null); // Clear the active seance ID
    localStorage.removeItem('timerState');
  };

  const pauseTimer = () => {
    clearTimer();
    setIsPaused(true);
    incrementInterruptions();
  };

  const resumeTimer = () => {
    if (!isPaused || timeLeft <= 0 || !pomodoroConfig) return;
    setIsPaused(false);
  };

  // Function to increment the interruptions counter
  const incrementInterruptions = () => setInterruptions(prev => prev + 1);

  useEffect(() => {
    const saved = localStorage.getItem('timerState');
    if (saved) {
      try {
        const data = JSON.parse(saved);

        setPhase(data.phase || 'idle');
        setIsPaused(data.isPaused || false);
        setTimeLeft(data.timeLeft || 0);
        setTimeElapsedTotal(data.timeElapsedTotal || 0);
        setPomodoroCount(data.pomodoroCount || 0);
        setPomodoroConfig(data.pomodoroConfig || null);
        setUpcomingBreakType(data.upcomingBreakType || 'courte');
        setActiveSeanceId(data.activeSeanceId || null); // Load activeSeanceId
        setInterruptions(data.interruptions || 0); // <-- Load interruptions
      } catch (e) {
        console.error('Failed to parse timerState from localStorage', e);
        localStorage.removeItem('timerState');
      }
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) {
      const data = {
        phase,
        isPaused,
        timeLeft,
        timeElapsedTotal,
        pomodoroCount,
        pomodoroConfig,
        upcomingBreakType,
        activeSeanceId,
        interruptions, // <-- Save interruptions
      };
      localStorage.setItem('timerState', JSON.stringify(data));
    }
  }, [phase, isPaused, timeLeft, timeElapsedTotal, pomodoroCount, pomodoroConfig, upcomingBreakType, activeSeanceId, loaded, interruptions]); // <-- Add interruptions to dependency array

  useEffect(() => {
    if (loaded && (phase === 'awaiting_break' || phase === 'awaiting_study')) {
      const audio = new Audio('/ringtone/phaseNotification.mp3');
      audio.play().catch(err => {
        console.warn('Notification sound failed to play:', err);
      });
    }
  }, [phase, loaded]);

  return (
    <TimerContext.Provider value={{
      phase,
      isPaused,
      timeLeft,
      timeElapsedTotal,
      pomodoroCount,
      pomodoroConfig,
      upcomingBreakType,
      loaded,
      activeSeanceId,
      setActiveSeanceId,
      startSeance,
      stopSeance,
      startBreak,
      resumeStudy,
      pauseTimer,
      resumeTimer,
      interruptions, // <-- Expose interruptions
      incrementInterruptions, // <-- Expose function to increment interruptions
    }}>
      {children}
    </TimerContext.Provider>
  );
};