import { Box } from "@mui/material"

export default function About() {
    return (
        <>
            <Box>
                About
            </Box>
        </>
    )
}