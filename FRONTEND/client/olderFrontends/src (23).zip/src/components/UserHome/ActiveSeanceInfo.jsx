// src/components/UserHome/ActiveSeanceInfo.jsx
import React, { useContext, useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Grid,
  IconButton,
  useTheme,
} from '@mui/material';
import { alpha } from '@mui/material/styles';
import { TimerContext } from '../../contexts/TimerContext';

import TimerIcon from '@mui/icons-material/Timer';
import HourglassFullIcon from '@mui/icons-material/HourglassFull';
import LoopIcon from '@mui/icons-material/Loop';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ScheduleIcon from '@mui/icons-material/Schedule';
import EventNoteIcon from '@mui/icons-material/EventNote';


export default function ActiveSeanceInfo({ onCreateSeanceClick }) {

  const theme = useTheme();
  const outerBox = theme.palette.custom.box.outer;
  const innerBox = theme.palette.custom.box.inner;
  const middleBox = theme.palette.custom.box.middleBox;

  const primaryColor = theme.palette.custom.color.primary;
  const specialColor = theme.palette.custom.color.special;

  const specialText = theme.palette.custom.text.special;
  const secondaryText = theme.palette.custom.text.secondary;
  const primaryText = theme.palette.custom.text.primary;

  const whiteBorder = theme.palette.custom.border.white;
  const blackBorder = theme.palette.custom.border.black;
  const specialBorder = theme.palette.custom.border.special;

  const softBoxShadow = theme.palette.custom.boxShadow.soft;


  const { pomodoroConfig, timeElapsedTotal, phase, timeLeft } = useContext(TimerContext);

  const [currentTimerViewIndex, setCurrentTimerViewIndex] = useState(0);

  const formatTime = (totalSeconds) => {
    if (isNaN(totalSeconds) || totalSeconds < 0) return "00:00:00";
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return [hours, minutes, seconds].map(unit => String(unit).padStart(2, '0')).join(':');
  };

  const getNextPhaseInfo = () => {
    if (!pomodoroConfig) return { label: 'N/A', value: '00:00:00' };
    switch (phase) {
      case 'study': return { label: 'Prochaine Pause dans', value: formatTime(timeLeft) };
      case 'break': return { label: 'Prochaine Étude dans', value: formatTime(timeLeft) };
      case 'awaiting_break': return { label: 'Prêt pour', value: 'La Pause' };
      case 'awaiting_study': return { label: 'Prêt pour', value: "L'Étude" };
      case 'completed': return { label: 'Statut', value: 'Terminée' };
      case 'idle':
      default: return { label: 'Inactif', value: '00:00:00' };
    }
  };

  const timerViews = [
    { label: "Temps Total Écoulé", value: formatTime(timeElapsedTotal), icon: <HourglassFullIcon /> },
    { label: "Temps Restant (Séance)", value: formatTime(pomodoroConfig ? pomodoroConfig.duree_seance_totale - timeElapsedTotal : 0), icon: <ScheduleIcon /> },
    { label: getNextPhaseInfo().label, value: getNextPhaseInfo().value, icon: getNextPhaseInfo().label.includes('Prêt') ? <PlayCircleOutlineIcon /> : <TimerIcon /> }
  ];

  const BigTimerDisplay = ({ label, value }) => (
    <Box sx={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      flexGrow: 1,
    }}>
      <Typography
        variant="subtitle1"
        fontWeight="bold"
        sx={{
          opacity: 0.8,
          mb: 0.5,
          textTransform: 'uppercase',
          letterSpacing: 1,
          color: specialText,
        }}
      >
        {label}
      </Typography>
      <Typography
        variant="h3"
        fontWeight="extraBold"
        sx={{
          lineHeight: 1,
          textShadow: '0 2px 4px rgba(0,0,0,0.1)',
          [theme.breakpoints.down('sm')]: {
            variant: 'h4',
          },
          color: specialText,
        }}
      >
        {value}
      </Typography>
    </Box>
  );

  const InfoPill = ({ label, value, icon }) => (
    <Box sx={{
      bgcolor: innerBox,
      backdropFilter: 'blur(8px)',
      border: `1px solid ${whiteBorder}`,
      borderRadius: '12px',
      p: '10px 15px',
      display: 'flex',
      alignItems: 'center',
      gap: 1.5,
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
      color: 'text.primary',
      width: '100%',
      minHeight: '50px',
    }}>
      {icon && React.cloneElement(icon, {
        sx: { fontSize: 24, color: theme.palette.text.primary, flexShrink: 0 }
      })}
      <Typography variant="body2" fontWeight="medium" sx={{ color: 'text.secondary', flexShrink: 0 }}>
        {label}:
      </Typography>
      <Typography variant="body1" sx={{
        color: 'text.primary',
        flexGrow: 1,
        textAlign: 'left',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
      }}>
        {value}
      </Typography>
    </Box>
  );

  const currentTimerView = timerViews[currentTimerViewIndex];

  return (
    <Box
      sx={{
        flexGrow: 1,
        backgroundColor: middleBox,
        backdropFilter: 'blur(8px)',
        border: `1px solid ${whiteBorder}`,
        borderRadius: '16px',
        p: 3,
        textAlign: 'center',
        color: primaryText,
        boxShadow: softBoxShadow,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        width: '100%'
      }}
    >
      {!pomodoroConfig ? (
        <Box sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '50%',
          width: '100%',
          gap: 2,
          p: 3,
          bgcolor: innerBox,
          backdropFilter: 'blur(10px)',
          border: `1px solid ${whiteBorder}`,
          borderRadius: '12px',
          boxShadow: softBoxShadow,
          transition: 'all 0.3s ease-in-out',
          '&:hover': {
            boxShadow: '0 6px 15px rgba(0, 0, 0, 0.15)',
          },
        }}>
          <Typography variant="h5" fontWeight="bold">
            Aucune séance active
          </Typography>
          <Typography variant="body1" sx={{ color: 'text.secondary', mb: 2 }}>
            Commencez une nouvelle session pour suivre votre progression !
          </Typography>
          <Button
            variant="contained"
            onClick={onCreateSeanceClick}
            sx={{
              fontWeight: 'bold',
              borderRadius: '8px',
              bgcolor: alpha(specialText,1),
              px: 3,
              py: 1.2,
              '&:hover': {
                bgcolor: alpha(specialText,0.8),
                transform: 'scale(1.05)',
              },
              transition: 'all 0.3s ease-in-out',
            }}
          >
            Créer une séance
          </Button>
        </Box>
      ) : (
        <>
          <Box sx={{ flexBasis: 'auto', mb: 2 }}>

            <Box sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              width: '100%',
              bgcolor: innerBox,
              borderRadius: '12px',
              border: `1px solid ${whiteBorder}`,
              boxShadow: softBoxShadow,
              p: 1.5,
            }}>
              <IconButton onClick={() => setCurrentTimerViewIndex((i) => (i - 1 + timerViews.length) % timerViews.length)}>
                <ChevronLeftIcon fontSize="large" />
              </IconButton>
              <BigTimerDisplay label={currentTimerView.label} value={currentTimerView.value} />
              <IconButton onClick={() => setCurrentTimerViewIndex((i) => (i + 1) % timerViews.length)}>
                <ChevronRightIcon fontSize="large" />
              </IconButton>
            </Box>
          </Box>

          <Box justifyContent="space-between" width="100%" display="flex" sx={{ overflowY: 'auto', pr: 1, mb: 2 }}>
            <Grid container width="100%" display="flex" justifyContent="center" spacing={1.5}>
              <Grid item width="40%"><InfoPill label="Thème" value={pomodoroConfig.theme || 'N/A'} icon={<EventNoteIcon />} /></Grid>
              <Grid item width="40%"><InfoPill label="Durée Étude" value={formatTime(pomodoroConfig.duree_seance)} icon={<TimerIcon />} /></Grid>
              <Grid item width="40%"><InfoPill label="Durée Pause Courte" value={formatTime(pomodoroConfig.duree_pause_courte)} icon={<TimerIcon />} /></Grid>
              <Grid item width="40%"><InfoPill label="Durée Pause Longue" value={formatTime(pomodoroConfig.duree_pause_longue)} icon={<TimerIcon />} /></Grid>
              <Grid item width="40%"><InfoPill label="Cycles avant Pause Longue" value={pomodoroConfig.nbre_pomodoro_avant_pause_longue} icon={<LoopIcon />} /></Grid>
              <Grid item width="40%"><InfoPill label="Durée Totale de la Séance" value={formatTime(pomodoroConfig.duree_seance_totale)} icon={<HourglassFullIcon />} /></Grid>
            </Grid>
          </Box>

          <Box sx={{ flexBasis: 'auto', p: 1, pt: 0, mt: 'auto' }}>
            <Typography variant="caption" color="text.disabled" sx={{ textAlign: 'center' }}>
              Plus de détails à venir...
            </Typography>
          </Box>
        </>
      )}
    </Box>
  );
}