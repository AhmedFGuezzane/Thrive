// src/components/common/ErrorBoundary.jsx
import React from "react";
import { Alert, AlertTitle } from "@mui/material";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught:", error, errorInfo);
    // Optional: send error to logging server here
  }

  render() {
    if (this.state.hasError) {
      return (
        <Alert severity="error" sx={{ m: 4 }}>
          <AlertTitle>Quelque chose a mal tourné</AlertTitle>
          {this.state.error?.message || "Erreur inconnue. Veuillez recharger l’application."}
        </Alert>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
