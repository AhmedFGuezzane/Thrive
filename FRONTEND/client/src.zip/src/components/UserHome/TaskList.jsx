// src/components/UserHome/TaskList.jsx
import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Button,
  CircularProgress,
  Chip,
  useTheme,
  Collapse,
  IconButton,
} from '@mui/material';
import axios from 'axios';
import config from '../../config'; // import your config

import DoneIcon from '@mui/icons-material/Done';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import ScheduleIcon from '@mui/icons-material/Schedule'; // For in progress
import KeyboardDoubleArrowUpIcon from '@mui/icons-material/KeyboardDoubleArrowUp'; // Importance 1
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp'; // Importance 2
import HorizontalRuleIcon from '@mui/icons-material/HorizontalRule'; // Importance 3
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'; // Importance 4
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown'; // Importance 5
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';

export default function TaskList({ seanceId }) {
  const theme = useTheme();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expandedTaskId, setExpandedTaskId] = useState(null);

  const handleExpandClick = (taskId) => {
    setExpandedTaskId((prevId) => (prevId === taskId ? null : taskId));
  };

  const getImportanceDisplay = (importance) => {
    switch (importance) {
      case 1:
        return {
          label: 'Urgent',
          bgColor: '#ef5350',
          textColor: '#ffffff',
          icon: <KeyboardDoubleArrowUpIcon fontSize="small" />,
        };
      case 2:
        return {
          label: 'Haute',
          bgColor: '#ff9800',
          textColor: '#ffffff',
          icon: <KeyboardArrowUpIcon fontSize="small" />,
        };
      case 3:
        return {
          label: 'Moyenne',
          bgColor: '#2196f3',
          textColor: '#ffffff',
          icon: <HorizontalRuleIcon fontSize="small" />,
        };
      case 4:
        return {
          label: 'Basse',
          bgColor: '#4caf50',
          textColor: '#ffffff',
          icon: <KeyboardArrowDownIcon fontSize="small" />,
        };
      case 5:
        return {
          label: 'Très Basse',
          bgColor: '#9c27b0',
          textColor: '#ffffff',
          icon: <KeyboardDoubleArrowDownIcon fontSize="small" />,
        };
      default:
        return {
          label: 'N/A',
          bgColor: '#9e9e9e',
          textColor: '#ffffff',
          icon: null,
        };
    }
  };

  const getStatusDisplay = (status) => {
    if (!status) {
      return {
        label: 'Inconnu',
        bgColor: '#9e9e9e',
        textColor: '#fff',
        icon: null,
      };
    }
    const normalizedStatus = status.trim().toLowerCase();
    switch (normalizedStatus) {
      case 'terminée':
      case 'complétée':
      case 'complete':
        return {
          label: 'Complétée',
          bgColor: '#9c27b0',
          textColor: '#ffffff',
          icon: <DoneIcon fontSize="small" />,
        };
      case 'en cours':
      case 'in progress':
        return {
          label: 'En cours',
          bgColor: '#4caf50',
          textColor: '#ffffff',
          icon: <ScheduleIcon fontSize="small" />,
        };
      case 'en attente':
      case 'pending':
        return {
          label: 'En attente',
          bgColor: '#ffc107',
          textColor: '#000000',
          icon: <HourglassEmptyIcon fontSize="small" />,
        };
      default:
        return {
          label: status,
          bgColor: '#9e9e9e',
          textColor: '#ffffff',
          icon: null,
        };
    }
  };

  const fetchTasks = async () => {
    if (!seanceId) {
      setTasks([]);
      return;
    }
    const token = localStorage.getItem('jwt_token');
    if (!token) {
      setTasks([]);
      return;
    }
    try {
      setLoading(true);
      const url = `${config.tacheMicroserviceBaseUrl}/taches/seance/${seanceId}`;
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setTasks(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Erreur lors de la récupération des tâches:', error);
      setTasks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [seanceId]);

  return (
    <Box
      width="50%"
      height="100%"
      sx={{
        backgroundColor: 'rgba(255, 240, 245, 0.2)',
        backdropFilter: 'blur(8px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
        borderRadius: '12px',
        p: 2,
        display: 'flex',
        flexDirection: 'column',
        gap: 1,
        overflowY: 'auto',
        color: '#333',
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
        <Typography variant="h6" fontWeight="bold" color="#333">
          Mes tâches
        </Typography>
        <Box textAlign="right">
          {seanceId && (
            <Typography variant="caption" color="textSecondary" sx={{ fontStyle: 'italic' }}>
              Séance ID : {seanceId.substring(0, 8)}...
            </Typography>
          )}
          <Button
            variant="outlined"
            size="small"
            onClick={fetchTasks}
            disabled={loading}
            sx={{
              borderColor: 'rgba(128, 0, 128, 0.5)',
              color: 'rgba(128, 0, 128, 0.9)',
              mt: 0.5,
              '&:hover': {
                borderColor: 'rgba(128, 0, 128, 0.8)',
                backgroundColor: 'rgba(128, 0, 128, 0.05)',
              },
            }}
          >
            {loading ? 'Chargement...' : 'Rafraîchir'}
          </Button>
        </Box>
      </Box>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
          <CircularProgress sx={{ color: 'rgba(128, 0, 128, 0.7)' }} />
        </Box>
      ) : tasks.length === 0 ? (
        <Typography variant="body2" color="textSecondary" sx={{ textAlign: 'center', mt: 2 }}>
          Aucune tâche pour cette séance.
        </Typography>
      ) : (
        tasks.map((task) => {
          const isExpanded = task.id === expandedTaskId;
          return (
            <Box
              key={task.id}
              onClick={() => handleExpandClick(task.id)}
              sx={{
                p: 2,
                bgcolor: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '12px',
                mb: 1,
                display: 'flex',
                flexDirection: 'column',
                gap: 1,
                border: '1px solid rgba(255, 255, 255, 0.2)',
                boxShadow: '0 2px 10px rgba(0, 0, 0, 0.05)',
                color: '#333',
                position: 'relative',
                overflow: 'hidden',
                transition: 'all 0.3s ease-in-out',
                cursor: 'pointer',
                '&:hover': {
                  bgcolor: 'rgba(255, 255, 255, 0.15)',
                  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)',
                  transform: 'translateY(-2px)',
                },
              }}
            >
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width="100%"
              >
                <Typography
                  variant="subtitle1"
                  fontWeight="bold"
                  color="#333"
                  sx={{ flexGrow: 1, mr: 1 }}
                >
                  {task.titre}
                </Typography>
                <Box display="flex" alignItems="center" gap={1}>
                  <Chip
                    label={getImportanceDisplay(task.importance).label}
                    size="small"
                    icon={getImportanceDisplay(task.importance).icon}
                    sx={{
                      backgroundColor: getImportanceDisplay(task.importance).bgColor,
                      color: getImportanceDisplay(task.importance).textColor,
                      fontWeight: 'bold',
                      borderRadius: '6px',
                      '.MuiChip-icon': { color: 'inherit !important' },
                      opacity: 0.9,
                      height: '24px',
                      px: '8px',
                    }}
                  />
                  {task.statut && (
                    <Chip
                      label={getStatusDisplay(task.statut).label}
                      size="small"
                      icon={getStatusDisplay(task.statut).icon}
                      sx={{
                        backgroundColor: getStatusDisplay(task.statut).bgColor,
                        color: getStatusDisplay(task.statut).textColor,
                        fontWeight: 'bold',
                        borderRadius: '6px',
                        '.MuiChip-icon': { color: 'inherit !important' },
                        opacity: 0.9,
                        height: '24px',
                        px: '8px',
                      }}
                    />
                  )}
                </Box>
                <IconButton size="small" sx={{ color: '#333', ml: 1 }}>
                  {isExpanded ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                </IconButton>
              </Box>

              <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                <Box sx={{ mt: 1, pt: 1, borderTop: '1px solid rgba(0,0,0,0.1)' }}>
                  {task.description && (
                    <Typography variant="body2" color="#444" sx={{ mb: 1, whiteSpace: 'pre-wrap' }}>
                      <Typography component="span" fontWeight="bold" sx={{ color: '#333' }}>
                        Description :{' '}
                      </Typography>
                      {task.description}
                    </Typography>
                  )}
                  <Typography variant="body2" color="#444">
                    <Typography component="span" fontWeight="bold" sx={{ color: '#333' }}>
                      Autres détails :{' '}
                    </Typography>
                    {task.date_creation &&
                      `Créée le: ${new Date(task.date_creation).toLocaleDateString()} `}
                    {task.date_modification &&
                      `Dernière modification: ${new Date(task.date_modification).toLocaleDateString()}`}
                    {!task.date_creation && !task.date_modification &&
                      'Aucune information supplémentaire.'}
                  </Typography>
                </Box>
              </Collapse>

              {task.date_fin && (
                <Typography variant="body2" sx={{ fontSize: '0.8rem', color: '#666', mt: 1 }}>
                  Échéance : {new Date(task.date_fin).toLocaleDateString()}
                </Typography>
              )}
            </Box>
          );
        })
      )}
    </Box>
  );
}
