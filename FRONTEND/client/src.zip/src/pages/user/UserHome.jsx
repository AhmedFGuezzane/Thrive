import React, { useState, useEffect, useContext } from 'react';
import { Box, Typography, Button, CircularProgress } from '@mui/material';

import SnackbarAlert from '../../components/common/SnackbarAlert';
import CreateSeanceDialog from '../../components/common/CreateSeanceDialog';
import TaskList from '../../components/UserHome/TaskList';
import TimerBar from '../../components/common/TimerBar';
import { TimerContext } from '../../contexts/TimerContext';
import { createSeance } from '../../utils/seanceService';

export default function UserHome() {
  const { startSeance } = useContext(TimerContext);

  const studyTips = [
    "Utilise la technique Pomodoro pour rester concentré sans t'épuiser.",
    "Fixe-toi des objectifs clairs avant chaque séance d'étude.",
    "Écoute de la musique douce ou ambiante pour te concentrer.",
    "Prends une pause toutes les 25 minutes pour recharger ton cerveau.",
    "Respire profondément et détends-toi avant de commencer.",
    "Élimine les distractions : mets ton téléphone en mode avion.",
    "Prends des notes à la main pour mieux retenir les informations.",
    "Récompense-toi après une bonne séance d'étude.",
    "Étudie à des heures où tu es naturellement plus concentré.",
    "Bois de l’eau régulièrement pour rester alerte."
  ];

  const [tipIndex, setTipIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const tipDuration = 8000;

  useEffect(() => {
    const start = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - start;
      const percentage = Math.min((elapsed / tipDuration) * 100, 100);
      setProgress(percentage);

      if (percentage >= 100) {
        setTipIndex((prev) => (prev + 1) % studyTips.length);
        setProgress(0);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [tipIndex]);

  const glassHomeBg = 'rgba(255, 240, 245, 0.2)';
  const glassHomeBorderColor = 'rgba(255, 255, 255, 0.1)';

  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeStep, setActiveStep] = useState(0);

  const [formData, setFormData] = useState({
    type_seance: "focus",
    nom: "Deep Work Session",
    pomodoro: {
      duree_seance: 1500,
      duree_pause_courte: 300,
      duree_pause_longue: 900,
      nbre_pomodoro_avant_pause_longue: 4,
      duree_seance_totale: 7200,
      auto_demarrage: true,
      alerte_sonore: true,
      notification: true,
      vibration: false,
      nom_seance: "Pomodoro Config A",
      theme: "dark",
      suivi_temps_total: true,
      nom_preconfiguration: "Standard Focus"
    }
  });

  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('info');

  const showSnackbar = (message, severity) => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const handleSnackbarClose = (_, reason) => {
    if (reason !== 'clickaway') setSnackbarOpen(false);
  };

  const handleDialogOpen = () => setDialogOpen(true);
  const handleDialogClose = () => {
    setDialogOpen(false);
    setTimeout(() => setActiveStep(0), 300);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handlePomodoroChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : (type === 'number' ? Number(value) : value);
    setFormData(prev => ({
      ...prev,
      pomodoro: { ...prev.pomodoro, [name]: newValue }
    }));
  };

  const handleSubmit = async () => {
    showSnackbar('Creating your session...', 'info');
    try {
      const result = await createSeance(formData);
      showSnackbar('Session créée avec succès !', 'success');
      startSeance(formData.pomodoro);
      handleDialogClose();
    } catch (err) {
      showSnackbar(`Erreur : ${err.message}`, 'error');
    }
  };

  return (
    <Box
      width="98%"
      height="100%"
      mx="auto"
      sx={{
        backgroundColor: glassHomeBg,
        backdropFilter: 'blur(8px)',
        border: `1px solid ${glassHomeBorderColor}`,
        boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
        borderRadius: '16px',
        p: 3,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'center',
        color: '#333',
        position: 'relative'
      }}
    >
      <Box flexGrow={1} display="flex" flexDirection="row" width="100%" height="100%" gap={2} pb={2}>
        
          <TaskList seanceId={localStorage.getItem("active_seance_id")} />

        
        <Box width="50%" height="100%" display="flex" flexDirection="column" gap={2}>
          <Box
            height="25%"
            sx={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              borderRadius: '16px',
              p: 3,
              boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
              color: '#fff',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: '200px',
            }}
          >
            <Typography variant="h4" fontWeight="bold" mb={2} color="rgb(128, 0, 128)" sx={{ textAlign: 'center', letterSpacing: '1px' }}>
              Astuces
            </Typography>
            <Box display="flex" alignItems="center" justifyContent="center" gap={3} flexGrow={1}>
              <CircularProgress
                variant="determinate"
                value={progress}
                size={25}
                thickness={6}
                sx={{
                  position: 'absolute',
                  top: 12,
                  left: 12,
                  color: 'rgba(128, 0, 128, 0.7)'
                }}
              />
              <Typography
                variant="h6"
                color="rgb(201, 94, 201)"
                sx={{
                  fontStyle: 'italic',
                  textAlign: 'left',
                  lineHeight: 1.5,
                  maxWidth: '80%',
                }}
              >
                {studyTips[tipIndex]}
              </Typography>
            </Box>
          </Box>
          <Box
            flexGrow={1}
            display="flex"
            alignItems="center"
            justifyContent="center"
            sx={{
              backgroundColor: glassHomeBg,
              backdropFilter: 'blur(8px)',
              border: `1px solid ${glassHomeBorderColor}`,
              borderRadius: '12px',
              p: 2
            }}
          >
            <Button
              variant="contained"
              onClick={handleDialogOpen}
              sx={{
                bgcolor: 'rgba(128, 0, 128, 0.4)',
                '&:hover': { bgcolor: 'rgba(128, 0, 128, 0.6)' }
              }}
            >
              Créer séance
            </Button>
          </Box>
        </Box>
      </Box>

      <TimerBar onCreateClick={handleDialogOpen} config={formData.pomodoro} />

      <CreateSeanceDialog
        open={dialogOpen}
        onClose={handleDialogClose}
        activeStep={activeStep}
        setActiveStep={setActiveStep}
        formData={formData}
        setFormData={setFormData}
        handleFormChange={handleFormChange}
        handlePomodoroChange={handlePomodoroChange}
        handleSubmit={handleSubmit}
      />

      <SnackbarAlert
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={handleSnackbarClose}
      />
    </Box>
  );
}
