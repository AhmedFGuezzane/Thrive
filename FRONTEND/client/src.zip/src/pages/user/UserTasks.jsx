import React, { useState } from 'react';
import { Box, Typography } from "@mui/material";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

import TimerBar from '../../components/common/TimerBar';

const initialTasks = {
  'todo': [
    { id: 'task-1', content: 'Review React Hooks documentation', priority: 'High' },
    { id: 'task-2', content: 'Plan next study session topics', priority: 'Medium' },
    { id: 'task-3', content: 'Read article on CSS-in-JS', priority: 'Low' },
  ],
  'doing': [],
  'done': []
};

export default function UserTasks() {
  const [tasks, setTasks] = useState(initialTasks);

  const glassPageBg = 'rgba(255, 240, 245, 0.2)';
  const glassBorderColor = 'rgba(255, 255, 255, 0.1)';

  const onDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;
    if (source.droppableId === destination.droppableId && source.index === destination.index) return;

    const start = tasks[source.droppableId];
    const finish = tasks[destination.droppableId];

    if (start === finish) {
      const newTasks = Array.from(start);
      const [moved] = newTasks.splice(source.index, 1);
      newTasks.splice(destination.index, 0, moved);
      setTasks(prev => ({ ...prev, [source.droppableId]: newTasks }));
    } else {
      const startTasks = Array.from(start);
      const [moved] = startTasks.splice(source.index, 1);
      const finishTasks = Array.from(finish);
      finishTasks.splice(destination.index, 0, moved);
      setTasks(prev => ({
        ...prev,
        [source.droppableId]: startTasks,
        [destination.droppableId]: finishTasks
      }));
    }
  };

  const getItemStyle = (isDragging, draggableStyle) => ({
    userSelect: 'none',
    padding: '8px',
    marginBottom: '8px',
    borderRadius: '8px',
    background: isDragging ? 'rgba(128, 0, 128, 0.6)' : 'rgba(255, 255, 255, 0.1)',
    color: isDragging ? '#fff' : '#333',
    border: isDragging ? '1px solid rgba(255, 255, 255, 0.5)' : '1px solid rgba(255, 255, 255, 0.1)',
    boxShadow: isDragging ? '0 2px 10px rgba(0,0,0,0.2)' : 'none',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    ...draggableStyle,
  });

  const getListStyle = (isDraggingOver) => ({
    background: isDraggingOver ? 'rgba(200, 160, 255, 0.4)' : glassPageBg,
    padding: '8px',
    borderRadius: '12px',
    flexGrow: 1,
    minHeight: '100px',
    overflowY: 'auto',
  });

  return (
    <Box
      width="98%"
      height="100%"
      mx="1rem"
      sx={{
        backgroundColor: glassPageBg,
        backdropFilter: 'blur(8px)',
        border: `1px solid ${glassBorderColor}`,
        boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
        borderRadius: '16px',
        p: 3,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'center',
        color: '#333',
        position: 'relative',
      }}
    >
      <Box flexGrow={1} width="100%" display="flex" flexDirection="row" gap={2} pb={2}>
        <DragDropContext onDragEnd={onDragEnd}>
          {Object.entries(tasks).map(([columnId, columnTasks]) => (
            <Droppable key={columnId} droppableId={columnId}>
              {(provided, snapshot) => (
                <Box
                  ref={provided.innerRef}
                  style={getListStyle(snapshot.isDraggingOver)}
                  {...provided.droppableProps}
                  sx={{
                    border: `1px solid ${glassBorderColor}`,
                    boxShadow: '0 2px 15px rgba(0, 0, 0, 0.08)',
                    display: 'flex',
                    flexDirection: 'column',
                    flexBasis: '33%',
                    minWidth: '200px',
                  }}
                >
                  <Typography variant="h6" fontWeight="bold" color="#333" mb={2} sx={{ textTransform: 'capitalize' }}>
                    {columnId.replace('todo', 'To Do').replace('doing', 'Doing').replace('done', 'Done')}
                  </Typography>
                  {columnTasks.length === 0 && (
                    <Typography variant="body2" color="#777" sx={{ textAlign: 'center', p: 2 }}>
                      No tasks here yet.
                    </Typography>
                  )}
                  {columnTasks.map((task, index) => (
                    <Draggable key={task.id} draggableId={task.id} index={index}>
                      {(provided, snapshot) => (
                        <Box
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}
                        >
                          <Typography variant="body1">{task.content}</Typography>
                          <Typography variant="body2" sx={{ fontSize: '0.75rem', color: '#666' }}>
                            {task.priority}
                          </Typography>
                        </Box>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </Box>
              )}
            </Droppable>
          ))}
        </DragDropContext>
      </Box>

      {/* ✅ Shared TimerBar (same as UserHome) */}
      <TimerBar onCreateClick={() => {}} />
    </Box>
  );
}
