export const createSeance = async (formData) => {
  try {
    const token = localStorage.getItem('jwt_token');
    if (!token) throw new Error("Authentication required");

    const payloadBase64 = token.split('.')[1];
    const decodedPayload = JSON.parse(atob(payloadBase64));
    const client_id = decodedPayload.sub;

    const date_debut = new Date();
    const date_fin = new Date(date_debut.getTime() + Number(formData.pomodoro.duree_seance_totale) * 1000);

    const payload = {
      client_id,
      type_seance: formData.type_seance,
      nom: formData.nom,
      date_debut: date_debut.toISOString(),
      date_fin: date_fin.toISOString(),
      statut: "en_cours",
      est_complete: false,
      interruptions: 0,
      nbre_pomodoro_effectues: 0,
      pomodoro: {
        ...formData.pomodoro,
        duree_seance: Number(formData.pomodoro.duree_seance),
        duree_pause_courte: Number(formData.pomodoro.duree_pause_courte),
        duree_pause_longue: Number(formData.pomodoro.duree_pause_longue),
        nbre_pomodoro_avant_pause_longue: Number(formData.pomodoro.nbre_pomodoro_avant_pause_longue),
        duree_seance_totale: Number(formData.pomodoro.duree_seance_totale)
      }
    };

    const res = await fetch('http://localhost:5010/seances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    if (!res.ok) throw new Error("Erreur lors de la création de la séance");

    const result = await res.json();

    // ✅ Accepts both flat and wrapped séance formats
    const seance = result?.seance || result;

    if (seance?.id) {
      localStorage.setItem("active_seance_id", seance.id);
    }

    return seance;
  } catch (err) {
    console.error("Erreur lors de la création de la séance:", err);
    throw err;
  }
};
